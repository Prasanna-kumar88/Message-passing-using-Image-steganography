from tkinter import *
from tkinter import messagebox
 
 
def Ok():
    password = e2.get()
 
    if(password == "") :
        messagebox.showinfo("", "Blank Not allowed")
 
 
    elif(password == "1234"):
 
        '''messagebox.showinfo("","Login Success")'''
        
        root.destroy()
        import decode
 
    else :
        messagebox.showinfo("","Incorrect PassKey")
 
 
root = Tk()
root.title("Login")
root.geometry("300x200")
global e2
 
Label(root, text="PassKey").place(x=10, y=40)
e2 = Entry(root)
e2.place(x=140, y=40)
e2.config(show="*")
 
 
Button(root, text="Login", command=Ok ,height = 3, width = 13).place(x=10, y=100)
 
root.mainloop()